import java.util.*;
import java.util.Scanner;
class Ledger
{
    public double interest;
    public double A;
    public String bank_name;
    public String borrow_name;
    public double lump_sum;
     void loan(String borrow_name,String bank_name,double A,double interest,double lump_sum,double emi)
    {
        this.borrow_name = borrow_name;
        this.bank_name = bank_name;
        this.A = A;
        this.interest = interest;
        this.lump_sum = lump_sum;
        if(lump_sum > emi)
        {
            emi = lump_sum-emi;
            System.out.println(emi+ " ");
        }else{
            //return 0;
        }
    }
    public static void payment(String borrow_name,String bank_name,double A,double interest,double lump_sum,double emi)
   {
       while(emi-- )
       {
           if(lump_sum > emi)
           emi = lump_sum-emi;
           A = A-lump_sum;
       }
       
       System.out.println("borrow_name"+   A);
   }
   public static void blance(String borrow_name,String bank_name,double A,double interest,double lump_sum,double emi)
   {
       if(lump_sum > emi)
           emi = lump_sum-emi;
           A = A-lump_sum;
           emi--;
           interest--;
       System.out.println("bank_name+ interset");
   }
    public static void main(String args[])
    {
        double principle,rate,time,emi,interest,A;
        Scanner sc = new Scanner(System.in);
        String borrow_name = sc.next();
        String bank_name = sc.next();
        principle = Double.parseDouble(args[0]);
        rate = Double.parseDouble(args[1]);
        time = Double.parseDouble(args[2]);
        interest = (principle * rate*time)/100;
        A = principle + interest;
        rate = rate/(12 * 100);
        time = time * 12;
        //emi = (principle * rate*Math.pow(1 + rate,time))/(Math.pow(1 + rate,time)-1);
        emi = (A * rate*Math.pow(1+rate,time))/(Math.pow(1+rate,time)-1);
        Ledger bank = new Ledger();
        Ledger payment = new Ledger();
        Ledger blance = new Ledger();
        Ledger 
        bank.loan();
        bank.payment();
        bank.blance();
        payment.loan();
        payment.blance();
        blance.loan();
        
    }
}